
const data=JSON.parse(document.getElementById('data').textContent);
const municipality=document.getElementById('municipality'),category=document.getElementById('category'),view=document.getElementById('view');
data.cases.forEach((c,i)=>municipality.add(new Option(c.name,i)));data.categories.forEach((c,i)=>category.add(new Option(c,i)));
function draw(){const c=data.cases[+municipality.value],k=+category.value,v=view.value,y=c[v][k],total=data.categories[k]==='Все категории';
const predicted=v==='levels'&&total?c.predictions:[];const all=y.concat(predicted.filter(x=>x!==null));let low=Math.min(...all),high=Math.max(...all);const pad=(high-low)*.12||1;low-=pad;high+=pad;
const X=i=>65+i*900/(data.dates.length-1),Y=z=>285-(z-low)/(high-low)*235;
const path=arr=>arr.map((z,i)=>z===null?'':`${i===0||arr[i-1]===null?'M':'L'}${X(i).toFixed(1)},${Y(z).toFixed(1)}`).join(' ');
let svg='';for(let j=0;j<=4;j++){const z=low+(high-low)*j/4;svg+=`<line x1="65" x2="965" y1="${Y(z)}" y2="${Y(z)}" stroke="#e2e8ec"/><text x="58" y="${Y(z)+4}" text-anchor="end" font-size="12">${v==='levels'?Math.round(z):z.toFixed(2)}</text>`;}
data.dates.forEach((d,i)=>{if(i%3===0)svg+=`<text x="${X(i)}" y="311" font-size="12" text-anchor="middle">${d.slice(0,7)}</text>`;});
const news=data.news.filter(n=>n.ids.includes(c.id)||n.region===45&&c.id===1333);
news.forEach(n=>{const i=data.dates.findIndex(d=>d.slice(0,7)===n.date.slice(0,7));if(i>=0)svg+=`<line x1="${X(i)}" x2="${X(i)}" y1="32" y2="285" stroke="#d88616" stroke-dasharray="5 4"/>`;});
svg+=`<path d="${path(y)}" fill="none" stroke="#126ca2" stroke-width="3"/>`;if(predicted.length)svg+=`<path d="${path(predicted)}" fill="none" stroke="#1b8a68" stroke-width="2" stroke-dasharray="7 4"/>`;
document.getElementById('chart').innerHTML=svg;const list=document.getElementById('news');list.replaceChildren();news.forEach(n=>{const p=document.createElement('p'),a=document.createElement('a');a.href=n.url;a.textContent=n.date+' — '+n.summary;p.appendChild(a);list.appendChild(p);});}
[municipality,category,view].forEach(x=>x.addEventListener('change',draw));draw();
